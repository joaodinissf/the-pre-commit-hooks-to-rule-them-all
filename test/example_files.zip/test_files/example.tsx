const App: React.FC = () => <div>Hello</div>;
