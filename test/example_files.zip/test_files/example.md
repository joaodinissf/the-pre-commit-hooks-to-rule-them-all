# Test Markdown File
This is a test markdown file with various formatting issues.

## Section 1
Here's some text without proper spacing.
And another line.


### Subsection
* List item 1
* List item 2
* List item 3


Here's a code block:
```python
def hello():
    print("hello")
```

#### Another section
Some more text here.

## Section 2
This line has trailing whitespace.

- Item 1
- Item 2
- Item 3

### Links and Images
Here's a [link](https://example.com) and an image: ![alt text](image.png)


Table:
| Column 1 | Column 2 |
|----------|----------|
| Data 1   | Data 2   |
| Data 3   | Data 4   |