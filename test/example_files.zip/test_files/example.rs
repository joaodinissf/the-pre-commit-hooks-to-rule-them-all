// Badly formatted Rust file
use std::collections::HashMap;

struct User{
name:String,
age:u32,
}

impl User{
fn new(name:String,age:u32)->Self{
User{name,age}
}

fn is_adult(&self)->bool{
self.age>=18
}

fn get_info(&self)->String{
format!("Name: {}, Age: {}",self.name,self.age)
}
}

fn main(){
let mut users=HashMap::new();

let user1=User::new("Alice".to_string(),25);
let user2=User::new("Bob".to_string(),17);

users.insert(1,user1);
users.insert(2,user2);

for(id,user) in &users{
println!("User {}: {}",id,user.get_info());
if user.is_adult(){
println!("This user is an adult");
}else{
println!("This user is a minor");
}
}
}